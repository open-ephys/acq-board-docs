#!/usr/bin/env bash

VERSTRING="2.0.0"
file="Rhythm-v${VERSTRING}.bit"
programmer="oe_programmer"

echo -e "\e[32mFlashing Rhythm bitfile version $VERSTRING\e[0m"
echo "This process will take some minutes."
echo "There are steps during the process where the progress bar might seem frozen, but the programmer is working in the background."
echo -e "\n"
read -n 1 -s -r -p "Press any key to continue..."
echo -e "\n"

pfolder="linux"

# Ejecutar el programador
"./${pfolder}/${programmer}" "$file"

# Capturar el código de salida del programador inmediatamente
ERRCODE=$?

if [ $ERRCODE -eq 0 ]; then
	echo -e "\e[32mSuccess.\e[0m"
	echo "Gateware version ${VERSTRING} programmed into the board."
else
	echo -e "\e[31mError while programming: ${ERRCODE}\e[0m"
	echo "Please completely unplug the board from power and USB, plug it again and try again."
	echo "If the problem persists contact support with a full log of this window."
fi

echo -e "\n"
read -n 1 -s -r -p "Press any key to finish..."
echo ""
