#!/bin/env bash

file=Rhythm_prog_v0_4.bit
programmer=oe_programmer
VERSTRING=v0.4

echo [32mFlashing Rhythm bitfile version $VERSTRING [0m
echo This process will take some minutes. 
echo There are steps during the process where the progress bar might seem frozen, but the programmer is working in the background.
echo -e "\n"
read -s -p "Press any key to continue"
echo -e "\n"

unamearch="$(uname -s)"
case "${unamearch}" in
    Linux*)     pfolder=linux;;
    Darwin*)    pfolder=osx;;
    *)         
	echo "Unsupported architecture"
	exit 1
	;;
esac

$pfolder/$programmer $file

if [ $? -eq 0 ] 
then
	echo [32mSuccess.[0m
	echo Gateware version %VERSTRING% programmed into the board.
else
	echo [31mError while programming: %ERRORLEVEL% [0m
	echo Please completely unplug the board from power and USB, plug it again and try again.
	echo If the problem persists contact support with a full log of this window.
fi

