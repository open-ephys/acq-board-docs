@echo off
setlocal
set VERSTRING=2.0.0
set BITFILE=Rhythm-v%VERSTRING%.bit
echo [32mFlashing Rhythm bitfile version %VERSTRING% [0m
echo This process will take some minutes. 
echo There are steps during the process where the progress bar might seem frozen, but the programmer is working in the background.
echo:
echo Press any key to continue
pause
win\oe_programmer.exe %BITFILE%
IF %ERRORLEVEL% EQU 0 (
echo [32mSuccess.[0m
echo Gateware version %VERSTRING% programmed into the board.
) ELSE (
echo [31mError while programming: %ERRORLEVEL% [0m
echo Please completely unplug the board from power and USB, plug it again and try again.
echo If the problem persists contact support with a full log of this window.
)
echo:
echo Press any key to finish
pause